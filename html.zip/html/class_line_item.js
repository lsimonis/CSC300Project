var class_line_item =
[
    [ "LineItem", "class_line_item.html#a929a70a6c9db4f7d70e80e476467227a", null ],
    [ "~LineItem", "class_line_item.html#a9276612abc13a1eb1d08aef90d4e9232", null ],
    [ "getProduct", "class_line_item.html#a36d955a4b8a45ba7e02b14deafae051b", null ],
    [ "getQuantity", "class_line_item.html#afa42b3e30049d4c7cecc5f68f3c81fc9", null ]
];