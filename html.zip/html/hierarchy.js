var hierarchy =
[
    [ "BusinessInfo", "class_business_info.html", null ],
    [ "Inventory", "class_inventory.html", null ],
    [ "Invoice", "class_invoice.html", null ],
    [ "LineItem", "class_line_item.html", null ],
    [ "Menu", "class_menu.html", [
      [ "BusinessMenu", "class_business_menu.html", null ],
      [ "Checkout", "class_checkout.html", null ],
      [ "MainMenu", "class_main_menu.html", null ],
      [ "ProductMenu", "class_product_menu.html", null ]
    ] ],
    [ "Product", "class_product.html", null ]
];