var hierarchy =
[
    [ "BusinessInfo", "db/dc0/class_business_info.html", null ],
    [ "Inventory", "da/d71/class_inventory.html", null ],
    [ "Invoice", "d1/de2/class_invoice.html", null ],
    [ "LineItem", "d8/da2/class_line_item.html", null ],
    [ "Menu", "d2/db8/class_menu.html", [
      [ "BusinessMenu", "d9/d2a/class_business_menu.html", null ],
      [ "Checkout", "de/d0d/class_checkout.html", null ],
      [ "MainMenu", "d4/d04/class_main_menu.html", null ],
      [ "ProductMenu", "d5/ddb/class_product_menu.html", null ]
    ] ],
    [ "Product", "dc/d42/class_product.html", null ]
];