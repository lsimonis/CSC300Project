var searchData=
[
  ['addlineitem',['addLineItem',['../d1/de2/class_invoice.html#a6f9a05aaf64d7ac6399fc451390bdfab',1,'Invoice']]],
  ['addproduct',['addProduct',['../da/d71/class_inventory.html#ad0f425c16e58993e1b649642cb7c5357',1,'Inventory']]]
];
