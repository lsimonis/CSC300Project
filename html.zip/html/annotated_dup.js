var annotated_dup =
[
    [ "BusinessInfo", "class_business_info.html", "class_business_info" ],
    [ "BusinessMenu", "class_business_menu.html", "class_business_menu" ],
    [ "Checkout", "class_checkout.html", "class_checkout" ],
    [ "Inventory", "class_inventory.html", "class_inventory" ],
    [ "Invoice", "class_invoice.html", "class_invoice" ],
    [ "LineItem", "class_line_item.html", "class_line_item" ],
    [ "MainMenu", "class_main_menu.html", "class_main_menu" ],
    [ "Menu", "class_menu.html", "class_menu" ],
    [ "Product", "class_product.html", "class_product" ],
    [ "ProductMenu", "class_product_menu.html", "class_product_menu" ]
];