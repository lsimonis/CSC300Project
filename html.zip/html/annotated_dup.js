var annotated_dup =
[
    [ "BusinessInfo", "db/dc0/class_business_info.html", "db/dc0/class_business_info" ],
    [ "BusinessMenu", "d9/d2a/class_business_menu.html", "d9/d2a/class_business_menu" ],
    [ "Checkout", "de/d0d/class_checkout.html", "de/d0d/class_checkout" ],
    [ "Inventory", "da/d71/class_inventory.html", "da/d71/class_inventory" ],
    [ "Invoice", "d1/de2/class_invoice.html", "d1/de2/class_invoice" ],
    [ "LineItem", "d8/da2/class_line_item.html", "d8/da2/class_line_item" ],
    [ "MainMenu", "d4/d04/class_main_menu.html", "d4/d04/class_main_menu" ],
    [ "Menu", "d2/db8/class_menu.html", "d2/db8/class_menu" ],
    [ "Product", "dc/d42/class_product.html", "dc/d42/class_product" ],
    [ "ProductMenu", "d5/ddb/class_product_menu.html", "d5/ddb/class_product_menu" ]
];